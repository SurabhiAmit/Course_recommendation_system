package edu.gatech.courseManagement.entity;

public class CourseCatalog {

    private int version;
    private boolean isCurrentCatalog;
}


