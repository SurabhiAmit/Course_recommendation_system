package edu.gatech.courseManagement.service;

public interface CourseManagementUiService {
    public void run();
}
