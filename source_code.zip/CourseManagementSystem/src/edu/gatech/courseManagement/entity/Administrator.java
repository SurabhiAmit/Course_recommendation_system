package edu.gatech.courseManagement.entity;

public class Administrator {

}
