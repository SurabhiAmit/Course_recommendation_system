package edu.gatech.courseManagement.repository;

public interface EntityCreationStrategy {

    public Object create(final Object []o);

}
