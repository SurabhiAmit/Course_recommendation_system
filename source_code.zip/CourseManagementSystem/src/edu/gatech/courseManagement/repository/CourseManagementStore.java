package edu.gatech.courseManagement.repository;

public interface CourseManagementStore {
    public CourseManagementRepository getRepository();
}
